<h1> Portfolio Project files for Udacity "Build a Portfolio Website" project </h1>

<strong><u>Featured Work:</u></strong>
<br>
<ul>
<li><h4> Favorite Movie Website </h4></li>
<li><h4> TBD </h4></li>
<li><h4> TBD </h4></li>
</ul>

<h2> Download Instructions </h2>
<ol>
<li><h4> Download repository from github https://github.com/alex-hernandez/Fullstack_Nanodegree_Portfolio </li></h4>
<li><h4> Unzip the file </li></h4>
<li><h4> Launch a web browser such as Google Chrome </li></h4>
<li><h4> On any webpage, go to file>open (or CTRL+O) </li></h4>
<li><h4> select the index file from the repository </li></h4>
</ol>


MIT License

Copyright (c) 2017 Alex Hernandez

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
